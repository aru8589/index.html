var FIELDS = [
  ['title', 'Title'], ['name', 'Full Name'], ['regStatus', 'Registration Status'],
  ['participatedAs', 'Participated as'], ['nationality', 'Nationality'],
  ['arrDate', 'Arrival Date'], ['arrSlot', 'Arrival Time Slot'], ['arrTime', 'Arrival Exact Time (IST)'],
  ['depDate', 'Departure Date'], ['depSlot', 'Departure Time Slot'], ['depTime', 'Departure Exact Time (IST)'],
  ['address', 'Personal Address'], ['accommodation', 'Accommodation'],
  ['emergency', 'Emergency Contact Number'], ['email', 'Email'], ['category', 'Category'],
  ['institution', 'Department, Institution/Organization'], ['meal', 'Lunch/Dinner'],
  ['outdoor', 'Outdoor Activities'], ['mobile', 'Mobile Number/Whatsapp']
];

function setup() {
  var ss = SpreadsheetApp.create('ICCSE-2026 Registrations');
  var sh = ss.getSheets()[0];
  sh.setName('Responses');
  sh.appendRow(['Submitted'].concat(FIELDS.map(function (f) { return f[1]; })));
  sh.getRange(1, 1, 1, FIELDS.length + 1).setFontWeight('bold');
  sh.setFrozenRows(1);
  PropertiesService.getScriptProperties().setProperty('SS_ID', ss.getId());
  Logger.log('Responses sheet: ' + ss.getUrl());
}

function doGet() {
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('ICCSE-2026 Registration')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function submitForm(d) {
  d.email = String(d.email || '').trim().toLowerCase();
  if (!String(d.name || '').trim() || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(d.email)) {
    throw new Error('Please enter your name and a valid email.');
  }

  var when = new Date();
  var row = [when].concat(FIELDS.map(function (f) { return d[f[0]] || ''; }));
  var emailCol = 2 + FIELDS.map(function (f) { return f[0]; }).indexOf('email');

  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var ss = SpreadsheetApp.openById(PropertiesService.getScriptProperties().getProperty('SS_ID'));
    var sh = ss.getSheetByName('Responses');
    var last = sh.getLastRow();
    var found = 0;
    if (last > 1) {
      var emails = sh.getRange(2, emailCol, last - 1, 1).getValues();
      for (var i = 0; i < emails.length; i++) {
        if (String(emails[i][0]).trim().toLowerCase() === d.email) { found = i + 2; break; }
      }
    }
    if (found) sh.getRange(found, 1, 1, row.length).setValues([row]);
    else sh.appendRow(row);
  } finally {
    lock.releaseLock();
  }

  var lines = FIELDS.filter(function (f) { return d[f[0]]; })
    .map(function (f) { return f[1] + ': ' + d[f[0]]; });
  try {
    MailApp.sendEmail({
      to: d.email,
      name: 'ICCSE-2026 Organizing Team',
      subject: 'ICCSE-2026: Copy of your registration response',
      body: 'Dear ' + d.name + ',\n\nThank you for registering for ICCSE-2026. Here is a copy of your response:\n\n' +
        lines.join('\n') + '\n\nIf any detail is incorrect, please submit the form again with the same email address.\n\n' +
        'Regards,\nICCSE-2026 Organizing Team'
    });
  } catch (err) {
    Logger.log('Mail failed for ' + d.email + ': ' + err);
  }
  return 'ok';
}
